# HABIB AI — HTML starter

বাংলা/English UI, কালো-পার্পল-গোল্ডেন থিম, animated orb, Gemini API backend, voice input, text-to-speech, local chat history, settings এবং YouTube/Chrome/Camera browser actions.

## নিরাপত্তা
Gemini API key কখনো HTML/JS-এ রাখবে না। `backend/.env`-এ রাখো। Public deployment-এর আগে HTTPS, authentication, rate limiting এবং usage limits যোগ করতে হবে। এই demo backend-এ production authentication নেই।

## Backend চালানো
কম্পিউটারে Node.js 20+ লাগবে।
1. `backend` ফোল্ডারে terminal খুলে `npm install`
2. `.env.example` কপি করে `.env` বানাও এবং `GEMINI_API_KEY` সেট করো
3. `npm start` — backend `http://localhost:3000`-এ চলবে

## HTML চালানো
প্রজেক্টের root folder-এ terminal:
`python -m http.server 8080`
তারপর browser-এ `http://localhost:8080` খোলো। Settings → Backend URL-এ `http://localhost:3000` দাও, Save Settings, Test Connection চাপো।

## Android ফোনে পরীক্ষা
ফোন ও কম্পিউটার একই Wi-Fi-তে থাকলে computer-এর LAN IP দিয়ে page ও backend খুলো, যেমন `http://192.168.x.x:8080` এবং backend URL `http://192.168.x.x:3000`। `ALLOWED_ORIGIN`-এ HTML page-এর origin সেট করো। HTTP-তে microphone/browser permissions সীমিত হতে পারে; বাস্তব ব্যবহারে HTTPS ব্যবহার করো।

## সীমাবদ্ধতা
Speech recognition browser-ভেদে আলাদা; Chrome-এ চেষ্টা করো এবং microphone permission দাও। “Continuous voice” শুধু উত্তর শেষে আবার listen করার চেষ্টা করে; সবসময় background “Hey Habib” wake-word নয়। YouTube/Chrome quick action web page খোলে; Camera browser permission-সহ preview চেষ্টা করে। সাধারণ HTML Android system-এর সব app নিয়ন্ত্রণ করতে পারে না। APK-এর জন্য native Android wrapper/Capacitor আলাদা করে দরকার। AI ভুল উত্তর দিতে পারে।
