import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();
const app=express();
app.use(cors({origin:process.env.ALLOWED_ORIGIN||"http://localhost:8080"}));
app.use(express.json({limit:"32kb"}));
app.get("/health",(_req,res)=>res.json({status:"ok",service:"HABIB AI Gemini backend"}));
app.post("/chat",async(req,res)=>{
 try{
  const {message,history=[]}=req.body??{};
  if(typeof message!=="string"||!message.trim())return res.status(400).json({error:"message is required"});
  if(!process.env.GEMINI_API_KEY)return res.status(500).json({error:"Server Gemini API key is not configured"});
  const contents=[];
  if(Array.isArray(history))for(const item of history.slice(-12)){
   const role=item?.role==="assistant"?"model":"user";
   const txt=String(item?.text??item?.content??"").slice(0,4000);
   if(txt.trim())contents.push({role,parts:[{text:txt}]});
  }
  contents.push({role:"user",parts:[{text:message.trim().slice(0,4000)}]});
  const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const upstream=await fetch(url,{method:"POST",headers:{"x-goog-api-key":process.env.GEMINI_API_KEY,"Content-Type":"application/json"},body:JSON.stringify({systemInstruction:{parts:[{text:"You are HABIB AI, a helpful personal assistant made in Bangladesh. Support Bengali and English. If the user writes Bangla, answer in Bengali script. Be accurate, clear, and honest about uncertainty."}]},contents,generationConfig:{temperature:.7,maxOutputTokens:1200}})});
  const data=await upstream.json();
  if(!upstream.ok){console.error("Gemini API error",upstream.status,data?.error?.message);return res.status(502).json({error:`Gemini API request failed (${upstream.status}); check key, model and quota.`})}
  const reply=(data?.candidates?.[0]?.content?.parts??[]).map(p=>p.text||"").join("").trim();
  if(!reply)return res.status(502).json({error:"Gemini returned no text"});
  res.json({reply});
 }catch(e){console.error(e);res.status(500).json({error:"Internal server error"})}
});
const port=Number(process.env.PORT||3000);
app.listen(port,"0.0.0.0",()=>console.log(`HABIB AI backend listening on ${port}`));
